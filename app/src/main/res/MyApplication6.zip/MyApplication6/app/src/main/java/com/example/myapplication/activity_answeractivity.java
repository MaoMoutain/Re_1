package com.example.myapplication;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
public class activity_answeractivity extends AppCompatActivity {
    //创建菜单，第一个是有道翻译，第二个退出
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.translation:
                Intent intent_translation=new Intent(Intent.ACTION_VIEW);
                intent_translation.setData(Uri.parse("http://fanyi.youdao.com/"));
                startActivity(intent_translation);
                break;
            case R.id.finish:
                ActivityCollector.finishAll();
                break;
            default:
        }
        return  true;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_answeractivity);
        ActivityCollector.addActivity(this);
        //实现返回主界面的功能
        Button button_return_home=(Button)findViewById(R.id.btn_home);
        button_return_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent_return_home=new Intent(activity_answeractivity.this,activity_main.class);
                startActivity(intent_return_home);
            }
        });
    }

}
