package com.example.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class activity_listprj extends AppCompatActivity {
    //ListView应用实验字母数组
    private  String[] data={
            "A","B","C","D","E","F","G",
            "H","I","J","K","L","M","N",
            "O","P","Q","R","S","T",
            "U","V","W","X","Y","Z"};
    //ListView应用实验
    private List<List_class> alphaList=new ArrayList<>();
    //创建菜单，第一个是有道翻译，第二个退出
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.translation:
                Intent intent_translation=new Intent(Intent.ACTION_VIEW);
                intent_translation.setData(Uri.parse("http://fanyi.youdao.com/"));
                startActivity(intent_translation);
                break;
            case R.id.finish:
                ActivityCollector.finishAll();
                break;
            default:
        }
        return  true;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listprj);
        ActivityCollector.addActivity(this);
        //ListView的简单用法，将内容显示出来，后期将改成加载数据库
        initAlpha();
        AlphaAdapter alph_adapter = new AlphaAdapter(activity_listprj.this, R.layout.alpha_item, alphaList);
        ListView listView = (ListView) findViewById(R.id.list_view);
        listView.setAdapter(alph_adapter);
        //ListView点击事件
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                List_class alpha =alphaList.get(position);
                Toast.makeText(activity_listprj.this,alpha.getName(),Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void initAlpha(){
        for (int i=0;i<2;i++){
            List_class A=new List_class("A",R.drawable.bg2);
            alphaList.add(A);
            List_class B=new List_class("A",R.drawable.bg2);
            alphaList.add(B);
        }
    }
}
