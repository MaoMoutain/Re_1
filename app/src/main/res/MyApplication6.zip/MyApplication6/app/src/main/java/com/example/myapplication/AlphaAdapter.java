package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AlphaAdapter extends ArrayAdapter<List_class> {
    //ListView实验中提高效率的一个缓存类
    class ViewHolder{
        ImageView alphaImage;
        TextView alphaName;
    }
    private int resourceId;
    public AlphaAdapter(Context context, int textViewResourceId, List<List_class> objects)
    {
        super(context,textViewResourceId,objects);
        resourceId=textViewResourceId;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        List_class alpha=getItem(position);
        View view;
        ViewHolder viewHolder;
        if (convertView==null) {
            view = LayoutInflater.from(getContext()).inflate(resourceId, parent, false);
            viewHolder=new ViewHolder();
            viewHolder.alphaImage=(ImageView) view.findViewById(R.id.alpha_image);
            viewHolder.alphaName=(TextView) view.findViewById(R.id.alpha_text);
            view.setTag(viewHolder);
        }
        else {
            view =convertView;
            viewHolder=(ViewHolder)view.getTag();
        }
        viewHolder.alphaName.setText(alpha.getName());
        viewHolder.alphaImage.setImageResource(alpha.getImageId());
        return view;
    }

}
